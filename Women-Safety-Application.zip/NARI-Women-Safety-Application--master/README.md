# NARI-Women-Safety-Application- 

# PRAVEG Hackathon Nirma University
![1](https://user-images.githubusercontent.com/85783343/195533735-95a4fe58-13ad-46e6-8253-5b6b0651efba.png)
![2](https://user-images.githubusercontent.com/85783343/195533760-b3e4556c-2f51-44a5-a09c-03d347584ae1.png)
![3](https://user-images.githubusercontent.com/85783343/195533779-1409e16f-39ae-46d3-92ae-aa5f3930edfe.png)

# Screenshots of the application

![2](https://user-images.githubusercontent.com/85783343/195534312-7d81f405-371c-4524-97ae-a279e003be00.jpeg)
![1jpeg](https://user-images.githubusercontent.com/85783343/195534333-86ec22aa-729c-4794-81cc-92e9fb5bb5bb.jpeg)
![3](https://user-images.githubusercontent.com/85783343/195534347-2168109f-21dd-4cfe-9b6d-657b19bb40d8.jpeg)




