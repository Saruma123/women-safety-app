package com.company.currentlocation;

public interface SelectListener {
    void onItemClicked(MyModel myModel);
}
